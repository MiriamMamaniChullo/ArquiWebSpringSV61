package pe.edu.upc.helpmefastspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpMeFastSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
