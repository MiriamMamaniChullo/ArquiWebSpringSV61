package pe.edu.upc.helpmefastspring.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.helpmefastspring.entities.Enfermero;

import java.util.List;
@Repository
public interface IEnfermeroRepository extends JpaRepository<Enfermero,Integer>{

    @Query("FROM Enfermero p WHERE p.nameEnfermero LIKE %:nameEnfermero% OR LOWER(p.nameEnfermero)" +
            "LIKE %:nameEnfermero% OR p.nameEnfermero LIKE %:nameEnfermero%")
    List<Enfermero> buscarNombre(@Param("nameEnfermero") String nameEnfermero);
}
